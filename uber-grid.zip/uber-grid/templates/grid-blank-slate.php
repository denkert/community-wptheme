<div class="uber-grid empty">
	<?php _e('There are no cells in this grid yet.', 'uber-grid')?>
</div>